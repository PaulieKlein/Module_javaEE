package com.bankonet.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bankonet.model.Client;
import com.bankonet.service.BanqueService;
import com.bankonet.service.BanqueServiceManager;

/**
 * Permet le contr�le des parametres login et password pour pouvoir acceder au
 * reste de l'application
 * 
 * @author Neobject
 */

public class TraiterLoginServlet extends HttpServlet {

    /**
     * Effectue l'authentification d'un client et r�cup�re ses informations.
     * 
     * <p>
     * Le bean <code>Client</code> est recherch� avec l'identifiant et le mot
     * de passe.
     * </p>
     * <p>
     * Si une instance est trouv�e :
     * </p>
     * <ul>
     * <li>Le bean <code>Client</code> elle est stock�e dans la session
     * <li>On se d�branche vers la page principale
     * </ul>
     * <p>
     * Sinon, on se d�branche vers la page d'erreur de connexion.
     * 
     * 
     * @param req
     *            Requ�te du servlet
     * @param res
     *            R�ponse du servlet
     * 
     * @exception javax.servlet.ServletException
     *                Erreur de fonctionnement du servlet
     */

    protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

        // R�cup�rer les champs du formulaire
        String identifiant = req.getParameter("identifiant");
        String motDePasse = req.getParameter("motDePasse");

        try {
            // Rechercher le client
            BanqueService banqueService = BanqueServiceManager.getBanqueService();
            Client c = banqueService.findClient(identifiant, motDePasse);

            // Le stocker dans la session
            HttpSession session = req.getSession(true);
            session.setAttribute("client", c);

           
        } catch (Exception e) {
            // Erreur de connexion
            e.printStackTrace();
           

        }
    }
}