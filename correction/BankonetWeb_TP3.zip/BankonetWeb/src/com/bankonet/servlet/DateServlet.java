package com.bankonet.servlet;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Affiche la date dans la console.
 * 
 * @author Neobject (c)
 */
public class DateServlet extends HttpServlet {
	/* (non-Javadoc)
	 * @see javax.servlet.GenericServlet#init(javax.servlet.ServletConfig)
	 */
	public void init(ServletConfig conf) throws ServletException {
		System.out.println("initialisation de DateServlet");
		super.init(conf);
	}

	public DateServlet() {
		System.out.println("appel au constructeur DateServlet");
	}

	public void destroy() {
		System.out.println("suppression de DateServlet");
		super.destroy();
	}

	
	
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		System.out.println("Bienvenue sur Bankonet");
		SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy");
		System.out.println("date du jour : " + sdf.format(new Date())) ;
		//this.getServletContext().getRequestDispatcher("/login.jsp").forward(req, res);
		
		res.sendRedirect(req.getContextPath()+"/login.jsp"); 
	}
}